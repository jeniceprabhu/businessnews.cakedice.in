 <style type="text/css">
 	.header-top .menu-top-left .tel{
 		color:white;
 	}
 	.header-top .menu-top-right .tel{
 		color: white;
 	}
 	.nav-menu a{
 		color:white;
 	}
 </style>
 <header id="header" id="home" style="background-color: black; color:white;">
			    <div class="container">
			    	<div class="row header-top align-items-center">
			    		<div class="col-lg-4 col-sm-4 menu-top-left">
			    			<a href="mailto:info@nullerrors.com"><span class="lnr lnr-location"></span></a>
			    			<a class="tel" href="mailto:michaelkingglobal@gmail.com">michaelkingglobal@gmail.com</a>
			    		</div>
			    		<div class="col-lg-4 menu-top-middle justify-content-center d-flex">
							<a href="index.php" style="color: red; font-weight: 900;">
							Business News
								<!--<img class="img-fluid" src="img/logo.png" alt="">-->
							</a>			    			
			    		</div>
			    		<div class="col-lg-4 col-sm-4 menu-top-right">
			    			<a class="tel" href="tel:+2349060121120">+2349060121120</a>
			    			<a href="tel:+2349060121120"><span class="lnr lnr-phone-handset"></span></a>
			    		</div>
			    	</div>
			    </div>	
			    	<hr>
			    <div class="container">	
			    	<div class="row align-items-center justify-content-center d-flex">
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="index.php">HOME</a></li>
				          <li class="menu-has-children"><a href="#">ABOUT US</a>
						  <ul>
				              <li><a href="#">Who we are?</a></li>
				              <li><a href="#">Our Mission & Vision</a></li>
							  <li><a href="#">Our Dream</a></li>
							  <li><a href="#">Leadership</a></li>
				            </ul>
						  </li>
				          <li><a href="#">OUR BUSINESS</a>
						  <ul>
				              <li><a href="#">Entrepreneurship</a></li>
				              <li><a href="#">Fashion Modeling</a></li>
							  <li><a href="#">Farming and Marketing</a></li>
							  <li><a href="#">Abattoir</a></li>
							  <li><a href="#">Writers</a></li>
							  <li><a href="#">Acting</a></li>
							  <li><a href="#">Investments</a></li>
							   <li><a href="#">Modeling</a></li>
							   <li><a href="#">Advertisements</a></li>
				            </ul></li>				          
				          <li><a href="training.html">HISTORY</a>
						  <ul>
				              <li><a href="#">Who we are</a></li>
				              <li><a href="#">Where we come from</a></li>
				            </ul></li>
				        
				          <li class="menu-has-children"><a href="">contact US</a>
				            <ul>
				              <li><a href="https://www.instagram.com/michaelking_global/">Instagram</a></li>
				              <li><a href="https://www.facebook.com/profile.php?id=100043485319393">Facebook</a></li>
							  <li><a href="https://twitter.com/MichaelKing_GLB">Twitter</a></li>
							  <li><a href="https://wa.me/2349060121120">Whatsapp</a></li>
							  <li><a href="mailto:michaelkingglobal@gmail.com">Gmail</a></li>
							  <li><a href="mailto:michaelkingglobal@gmail.com
">Hangouts</a></li>
							  
				            </ul>
				          </li>
				          
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header>